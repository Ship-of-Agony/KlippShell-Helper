::[Bat To Exe Converter]
::
::fBE1pAF6MU+EWHreyHcjLQlHcDSQM0qoEvUv/P3/5uWlrUIWaMY6a4TP1aSyDuUG71ekWoQp2H9IpOooLlt7cR+mbwEwlW9GtCqAL8L8
::fBE1pAF6MU+EWHreyHcjLQlHcDSQM0qoEvUv/P3/5uWlrUIWaMY6a4TP1aSyDuUG71ekWoQp2H9IpOooLlt7cR+mbwEwlU9GtFOMOeaMukHlRkTp
::fBE1pAF6MU+EWHreyHcjLQlHcDSQM0qoEvUv/P3/5uWlrUIWaMY6a4TP1aSyDuUG71ekWoQp2H9IpOooLlt7cR+mbwEwlU9GtFOMOfKPsS7xQwaN6kdQ
::YAwzoRdxOk+EWAjk
::fBw5plQjdCyDJGyX8VAjFCtGQyWQKCuJEqAY4efZ4OWMnmkYR+krd5/n9LGbJfJTxVfge5M/6lt+uosvAxZVfxyvUgQ4oH4Mv2eKVw==
::YAwzuBVtJxjWCl3EqQJgSA==
::ZR4luwNxJguZRRnk
::Yhs/ulQjdF+5
::cxAkpRVqdFKZSDk=
::cBs/ulQjdF+5
::ZR41oxFsdFKZSDk=
::eBoioBt6dFKZSDk=
::cRo6pxp7LAbNWATEpSI=
::egkzugNsPRvcWATEpSI=
::dAsiuh18IRvcCxnZtBNQ
::cRYluBh/LU+EWAjk
::YxY4rhs+aU+IeA==
::cxY6rQJ7JhzQF1fEqQJhZksaHErSXA==
::ZQ05rAF9IBncCkqN+0xwdVsFAlTMbCXqZg==
::ZQ05rAF9IAHYFVzEqQIbJBJEXDeKOWe2Rp0Z5Pj+/Yo=
::eg0/rx1wNQPfEVWB+kM9LVsJDC+ONXuqNb0Z5OS7x++LskgPNA==
::fBEirQZwNQPfEVWB+kM9LVsJDC+ONXuqNb0Z5OS7x++LskgPNA==
::cRolqwZ3JBvQF1fEqQIRLA1VQgeHOCu8E7sf/OH04fnHpEIPFMkzcZ/L6byLLOxT/EzlNbcJ9DpZl8YBDRVcbXI=
::dhA7uBVwLU+EWGqM/VJwJx0UbQONMnL6KpQ++4g=
::YQ03rBFzNR3SWATElA==
::dhAmsQZ3MwfNWATE21I1JltnQxGQP27a
::ZQ0/vhVqMQ3MEVWAtB9wSA==
::Zg8zqx1/OA3MEVWAtB9wSA==
::dhA7pRFwIByZRRmM4FYgO0EbAwOLKGOvBPsf5+W03OKOsgASUq8ef4DVw/ulLOkD+nbscJohgllIncoABQ9BHg==
::Zh4grVQjdCyDJGyX8VAjFCtGQyWQKCuJEqAY4efZ4OWMnmkYR+krd5/n9LGbJfJTxVfge5M/6lt+uosvAxZVfxyvUiQ4oH5ShWyAO8u0tgPxT1rH41M1ew==
::YB416Ek+ZG8=
::
::
::978f952a14a936cc963da21a135fa983
@echo off
chcp 65001 > nul
title KlippShell Helper - TV Erweiterungen

cd /d "%~dp0"

if exist "%MYFILES%\adb.exe" (
    set "ADB_PATH=%MYFILES%\adb.exe"
) else (
    set "ADB_PATH=adb.exe"
)

set "ADB_VENDOR_KEYS=%USERPROFILE%\.android"

taskkill /f /im adb.exe > nul 2>&1

for /f "tokens=2 delims==" %%a in ('wmic os get locale /value 2^>nul') do set "OS_LOCALE=%%a"
set "LANG=EN"
if "%OS_LOCALE%"=="0407" set "LANG=DE"
if "%OS_LOCALE%"=="0405" set "LANG=CS"
if "%OS_LOCALE%"=="040c" set "LANG=FR"
if "%OS_LOCALE%"=="040a" set "LANG=ES"
if "%OS_LOCALE%"=="0415" set "LANG=PL"
if "%OS_LOCALE%"=="0419" set "LANG=RU"

if "%LANG%"=="DE" goto lang_de
if "%LANG%"=="CS" goto lang_cs
if "%LANG%"=="FR" goto lang_fr
if "%LANG%"=="ES" goto lang_es
if "%LANG%"=="PL" goto lang_pl
if "%LANG%"=="RU" goto lang_ru
goto lang_en

:lang_de
set "MSG_TITLE=Erweiterte Funktionen fuer KlippShell"
set "MSG_MENU=Waehle die gewuenschte Funktion aus:"
set "OPT_1=[1] Natives PiP ^(Picture-in-Picture^) aktivieren"
set "OPT_2=[2] TV Overlay ^(Schwebendes Fenster^) aktivieren"
set "OPT_3=[3] Hintergrund-Aktivitaet dauerhaft erlauben ^(Doze Whitelist^)"
set "OPT_4=[4] ALLE 3 FUNKTIONEN AKTIVIEREN ^(Empfohlen^)"
set "OPT_5=[5] ALLE RECHTE WIEDER ENTZIEHEN ^(Reset / Undo^)"
set "OPT_6=[6] Beenden"
set "STEP_1=[SCHRITT 1] Bitte die IP-Adresse des TVs eingeben ^(z.B. 192.168.1.50^):"
set "STEP_2=[SCHRITT 2] Starte ADB-Server..."
set "STEP_3=[SCHRITT 3] Verbinde mit"
set "AUTH_1=[RECHTE-CHECK] WARTE AUF AUTORISIERUNG AM FERNSEHER..."
set "AUTH_2=Bitte schaue JETZT auf deinen TV-Bildschirm."
set "AUTH_3=Bestaetige die Abfrage mit 'Immer von diesem Computer zulassen'."
set "SUCCESS=[ERFOLGREICH] Fernseher hat den PC autorisiert!"
set "EXEC=FUEHRE AUS:"
set "CMD_OK=[OK] - Erfolgreich ausgefuehrt"
set "CMD_ERR=[FEHLER] - Befehl fehlgeschlagen"
set "ERR_IP=[FEHLER] Keine IP-Adresse eingegeben. Neustart..."
set "DISC=Trenne ADB-Verbindung..."
set "END=Vorgang abgeschlossen. Druecke eine beliebige Taste zum Beenden."
goto main_menu

:lang_cs
set "MSG_TITLE=Rozsirene funkce pro KlippShell"
set "MSG_MENU=Vyberte pozadovanou funkci:"
set "OPT_1=[1] Povolit nativni PiP ^(Obraz v obraze^)"
set "OPT_2=[2] Povolit TV Overlay ^(Plovouci okno^)"
set "OPT_3=[3] Povolit aktivitu na pozadi ^(Doze Whitelist^)"
set "OPT_4=[4] POVOLIT VSECHNY 3 FUNCKE ^(Doporuceno^)"
set "OPT_5=[5] ODEBRAT VSECHNA OPRAVNENI ^(Reset / Undo^)"
set "OPT_6=[6] Ukoncit"
set "STEP_1=[KROK 1] Zadejte IP adresu TV ^(napr. 192.168.1.50^):"
set "STEP_2=[KROK 2] Spousteni ADB serveru..."
set "STEP_3=[KROK 3] Pripojovani k"
set "AUTH_1=[KONTROLA AUTORIZACE] CEKANI NA TV..."
set "AUTH_2=Podivejte se NYNI na obrazovku TV."
set "AUTH_3=Potvrdte 'Vzdy povolit z tohoto pocitace'."
set "SUCCESS=[USPESNE] TV autorizoval PC!"
set "EXEC=PROVADIM:"
set "CMD_OK=[OK] - Uspesne provedeno"
set "CMD_ERR=[CHYBA] - Prikaz selhal"
set "ERR_IP=[CHYBA] Nezadal jste IP adresu. Restart..."
set "DISC=Odpojovani ADB..."
set "END=Proces dokoncen. Stisknete libovolnou klavesu pro ukonceni."
goto main_menu

:lang_fr
set "MSG_TITLE=Fonctionnalites etendues pour KlippShell"
set "MSG_MENU=Selectionnez la fonctionnalite souhaitee :"
set "OPT_1=[1] Activer le PiP natif ^(Image dans l'image^)"
set "OPT_2=[2] Activer la superposition TV ^(Fenetre flottante^)"
set "OPT_3=[3] Autoriser l'activite en arriere-plan ^(Doze Whitelist^)"
set "OPT_4=[4] ACTIVER LES 3 FONCTIONNALITES ^(Recommande^)"
set "OPT_5=[5] REVOKER TOUTES LES AUTORISATIONS ^(Reset / Undo^)"
set "OPT_6=[6] Quitter"
set "STEP_1=[ETAPE 1] Veuillez entrer l'adresse IP du televiseur ^(ex. 192.168.1.50^) :"
set "STEP_2=[ETAPE 2] Demarrage du serveur ADB..."
set "STEP_3=[ETAPE 3] Connexion a"
set "AUTH_1=[VERIFICATION] EN ATTENTE D'AUTORISATION DU TELEVISEUR..."
set "AUTH_2=Regardez l'ecran de votre televiseur MAINTENANT."
set "AUTH_3=Confirmez 'Toujours autoriser depuis cet ordinateur'."
set "SUCCESS=[SUCCES] Le televiseur a autorise le PC !"
set "EXEC=EXECUTION :"
set "CMD_OK=[OK] - Execute avec succes"
set "CMD_ERR=[ERREUR] - Echec de la commande"
set "ERR_IP=[ERREUR] Aucune IP saisie. Redemarrage..."
set "DISC=Deconnexion d'ADB..."
set "END=Processus termine. Appuyez sur une touche pour quitter."
goto main_menu

:lang_es
set "MSG_TITLE=Funciones ampliadas para KlippShell"
set "MSG_MENU=Seleccione la funcion deseada:"
set "OPT_1=[1] Habilitar PiP nativo ^(Imagen en imagen^)"
set "OPT_2=[2] Habilitar superposicion de TV ^(Ventana flotante^)"
set "OPT_3=[3] Permitir actividad en segundo plano ^(Doze Whitelist^)"
set "OPT_4=[4] HABILITAR LAS 3 FUNCIONES ^(Recomendado^)"
set "OPT_5=[5] REVOCAR TODOS LOS PERMISOS ^(Reset / Undo^)"
set "OPT_6=[6] Salir"
set "STEP_1=[PASO 1] Ingrese la direccion IP del televisor ^(ej. 192.168.1.50^):"
set "STEP_2=[PASO 2] Iniciando el servidor ADB..."
set "STEP_3=[PASO 3] Conectando a"
set "AUTH_1=[VERIFICACION] ESPERANDO AUTORIZACION DEL TELEVISOR..."
set "AUTH_2=Mire la pantalla de su televisor AHORA."
set "AUTH_3=Confirme 'Permitir siempre desde esta computadora'."
set "SUCCESS=[EXITO] El televisor ha autorizado al PC!"
set "EXEC=EJECUTANDO:"
set "CMD_OK=[OK] - Ejecutado con exito"
set "CMD_ERR=[ERROR] - Fallo en el comando"
set "ERR_IP=[ERROR] No se ingreso ninguna IP. Reiniciando..."
set "DISC=Desconectando ADB..."
set "END=Proceso finalizado. Presione cualquier tecla para salir."
goto main_menu

:lang_pl
set "MSG_TITLE=Rozszerzone funkcje dla KlippShell"
set "MSG_MENU=Wybierz zadana funkcje:"
set "OPT_1=[1] Wlacz natywne PiP ^(Obraz w obrazie^)"
set "OPT_2=[2] Wlacz nakladke TV ^(Plywajace okno^)"
set "OPT_3=[3] Zezwol na dzialanie w tle ^(Doze Whitelist^)"
set "OPT_4=[4] WLACZ WSZYSTKIE 3 FUNKCJE ^(Zalecane^)"
set "OPT_5=[5] COFNIJ WSZYSTKIE UPRAWNIENIA ^(Reset / Undo^)"
set "OPT_6=[6] Wyjdz"
set "STEP_1=[KROK 1] Wprowadz adres IP telewizora ^(np. 192.168.1.50^):"
set "STEP_2=[KROK 2] Uruchamianie serwera ADB..."
set "STEP_3=[KROK 3] Laczenie z"
set "AUTH_1=[AUTORYZACJA] OCZEKIWANIE NA TELEWIZOR..."
set "AUTH_2=Spojrz TERAZ na ekran telewizora."
set "AUTH_3=Potwierdz 'Zawsze zezwalaj z tego komputera'."
set "SUCCESS=[SUKCES] Telewizor autoryzowal komputer!"
set "EXEC=WYKONYWANIE:"
set "CMD_OK=[OK] - Wykonano pomyslnie"
set "CMD_ERR=[BLAD] - Polecenie nie powiodlo sie"
set "ERR_IP=[BLAD] Brak adresu IP. Restart..."
set "DISC=Rozlaczanie ADB..."
set "END=Proces zakonczony. Nacisnij dowolny klawisz, aby wyjsc."
goto main_menu

:lang_ru
set "MSG_TITLE=Расширенные функции для KlippShell"
set "MSG_MENU=Выберите нужную функцию:"
set "OPT_1=[1] Включить нативный PiP ^(Картинка в картинке^)"
set "OPT_2=[2] Включить оверлей ТВ ^(Плавающее окно^)"
set "OPT_3=[3] Разрешить работу в фоновом режиме ^(Doze Whitelist^)"
set "OPT_4=[4] ВКЛЮЧИТЬ ВСЕ 3 ФУНКЦИИ ^(Рекомендуется^)"
set "OPT_5=[5] ОТОЗВАТЬ ВСЕ РАЗРЕШЕНИЯ ^(Сброс / Undo^)"
set "OPT_6=[6] Выход"
set "STEP_1=[ШАГ 1] Введите IP-адрес телевизора ^(например, 192.168.1.50^):"
set "STEP_2=[ШАГ 2] Запуск ADB сервера..."
set "STEP_3=[ШАГ 3] Подключение к"
set "AUTH_1=[ПРОВЕРКА] ОЖИДАНИЕ АВТОРИЗАЦИИ ТВ..."
set "AUTH_2=Посмотрите на экран телевизора СЕЙЧАС."
set "AUTH_3=Подтвердите 'Всегда разрешать с этого компьютера'."
set "SUCCESS=[УСПЕШНО] Телевизор авторизовал ПК!"
set "EXEC=ВЫПОЛНЕНИЕ:"
set "CMD_OK=[ОК] - Успешно выполнено"
set "CMD_ERR=[ОШИБКА] - Команда не выполнена"
set "ERR_IP=[ОШИБКА] IP-адрес не введен. Перезапуск..."
set "DISC=Отключение ADB..."
set "END=Процесс завершен. Нажмите любую клавишу для выхода."
goto main_menu

:lang_en
set "MSG_TITLE=Extended Features for KlippShell"
set "MSG_MENU=Select the desired feature:"
set "OPT_1=[1] Enable Native PiP ^(Picture-in-Picture^)"
set "OPT_2=[2] Enable TV Overlay ^(Floating Window^)"
set "OPT_3=[3] Allow Background Activity ^(Doze Whitelist^)"
set "OPT_4=[4] ENABLE ALL 3 FEATURES ^(Recommended^)"
set "OPT_5=[5] REVOKE ALL PERMISSIONS ^(Reset / Undo^)"
set "OPT_6=[6] Exit"
set "STEP_1=[STEP 1] Please enter TV IP address ^(e.g., 192.168.1.50^):"
set "STEP_2=[STEP 2] Starting ADB Server..."
set "STEP_3=[STEP 3] Connecting to"
set "AUTH_1=[AUTH CHECK] WAITING FOR TV AUTHORIZATION..."
set "AUTH_2=Please look at your TV screen NOW."
set "AUTH_3=Confirm the prompt with 'Always allow from this computer'."
set "SUCCESS=[SUCCESS] TV authorized the PC!"
set "EXEC=EXECUTING:"
set "CMD_OK=[OK] - Successfully executed"
set "CMD_ERR=[ERROR] - Command failed"
set "ERR_IP=[ERROR] No IP address entered. Restarting..."
set "DISC=Disconnecting ADB..."
set "END=Process finished. Press any key to exit."
goto main_menu

:main_menu
cls
echo =======================================================================
echo   [ KlippShell Helper ]  -  %MSG_TITLE%
echo   Developed by: Ship of Agony LABs
echo =======================================================================
echo.
echo   %MSG_MENU%
echo.
echo   %OPT_1%
echo   %OPT_2%
echo   %OPT_3%
echo   %OPT_4%
echo.
echo   %OPT_5%
echo.
echo   %OPT_6%
echo -----------------------------------------------------------------------

choice /c 123456 /n /m "> "
if errorlevel 6 exit
if errorlevel 5 (set "TASK=REVOKE" & goto get_ip)
if errorlevel 4 (set "TASK=ALL" & goto get_ip)
if errorlevel 3 (set "TASK=DOZE" & goto get_ip)
if errorlevel 2 (set "TASK=OVERLAY" & goto get_ip)
if errorlevel 1 (set "TASK=PIP" & goto get_ip)

:get_ip
echo.
echo %STEP_1%
set /p TV_IP="> "
if "%TV_IP%"=="" goto error_empty_ip

echo.
echo %STEP_2%
"%ADB_PATH%" kill-server > nul 2>&1
"%ADB_PATH%" start-server

echo.
echo %STEP_3% %TV_IP%:5555...
"%ADB_PATH%" connect %TV_IP%:5555
echo.

echo -----------------------------------------------------------------------
echo %AUTH_1%
echo %AUTH_2%
echo %AUTH_3%
echo -----------------------------------------------------------------------

:auth_loop
timeout /t 2 > nul
"%ADB_PATH%" devices 2>nul | findstr /C:"%TV_IP%:5555" | findstr /V "unauthorized" | findstr "device" > nul 2>&1
if %errorlevel% equ 0 goto exec_router

"%ADB_PATH%" devices 2>nul | findstr /C:"%TV_IP%:5555" > nul 2>&1
if %errorlevel% neq 0 "%ADB_PATH%" connect %TV_IP%:5555 > nul 2>&1

goto auth_loop

:exec_router
echo.
echo %SUCCESS%
echo.

if "%TASK%"=="REVOKE" goto run_revoke
if "%TASK%"=="ALL" goto run_pip
if "%TASK%"=="PIP" goto run_pip
if "%TASK%"=="OVERLAY" goto run_overlay
if "%TASK%"=="DOZE" goto run_doze
goto disconnect

:run_pip
echo %EXEC% Natives PiP / Picture-in-Picture...
echo - adb -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality PICTURE_IN_PICTURE allow
"%ADB_PATH%" -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality PICTURE_IN_PICTURE allow
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo.
if "%TASK%"=="ALL" goto run_overlay
goto disconnect

:run_overlay
echo %EXEC% TV Overlay / SYSTEM_ALERT_WINDOW...
echo - adb -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality SYSTEM_ALERT_WINDOW allow
"%ADB_PATH%" -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality SYSTEM_ALERT_WINDOW allow
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo.
if "%TASK%"=="ALL" goto run_doze
goto disconnect

:run_doze
echo %EXEC% Doze Whitelist...
echo - adb -s %TV_IP%:5555 shell dumpsys deviceidle whitelist +com.shipofagony.klippshell4creality
"%ADB_PATH%" -s %TV_IP%:5555 shell dumpsys deviceidle whitelist +com.shipofagony.klippshell4creality
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo.
goto disconnect

:run_revoke
echo %EXEC% Reset / Undo (Alle Rechte entziehen)...
echo - adb -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality PICTURE_IN_PICTURE default
"%ADB_PATH%" -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality PICTURE_IN_PICTURE default
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo - adb -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality SYSTEM_ALERT_WINDOW default
"%ADB_PATH%" -s %TV_IP%:5555 shell appops set com.shipofagony.klippshell4creality SYSTEM_ALERT_WINDOW default
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo - adb -s %TV_IP%:5555 shell dumpsys deviceidle whitelist -com.shipofagony.klippshell4creality
"%ADB_PATH%" -s %TV_IP%:5555 shell dumpsys deviceidle whitelist -com.shipofagony.klippshell4creality
if %errorlevel% equ 0 (echo %CMD_OK%) else (echo %CMD_ERR%)
echo.
goto disconnect

:disconnect
echo %DISC%
"%ADB_PATH%" disconnect %TV_IP%:5555 > nul 2>&1
goto end_pause

:error_empty_ip
echo.
echo %ERR_IP%
timeout /t 3 > nul
goto main_menu

:end_pause
echo.
echo =======================================================================
echo %END%
echo =======================================================================
pause > nul